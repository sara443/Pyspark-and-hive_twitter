# Import your dependencies
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

# Start up your PySpark session as always
# Don't run this more than once
spark = SparkSession.builder \
        .appName("myApp") \
        .enableHiveSupport() \
        .getOrCreate()
spark.conf.set("hive.metastore.uris", "thrift://localhost:5432")
spark.conf.set("spark.sql.sources.default", "parquet") 

# Read the tweet data from socket
tweet_df = spark.readStream \
    .format("socket") \
    .option("host", "127.0.0.1") \
    .option("port", 7777) \
    .load()

# Type cast the column value
# Convert the decoded to string
tweet_df_string = tweet_df.selectExpr("CAST(value AS STRING)")

writeTweet = tweet_df_string.writeStream \
    .outputMode("append") \
    .format("memory") \
    .queryName("tweetquery") \
    .trigger(processingTime='2 seconds') \
    .start()

# Sleep for 60 seconds
import time
time.sleep(60)

# Print a message indicating that streaming is running
print("----- Streaming is running -------")

df = spark.sql("select * from tweetquery")

schema = StructType([
    StructField("tweet_text", StringType(), True),
    StructField("created_at", StringType(), True),
    StructField("tweet_id", StringType(), True)
])

rdd = df.rdd.flatMap(lambda row: row.value.replace('}{', '}***{').split('***'))

df = spark.read.json(rdd, schema=schema)

df = df.withColumn("year", year("created_at"))
df = df.withColumn("month", month("created_at"))
df = df.withColumn("day", dayofmonth("created_at"))
df = df.withColumn("hour", hour("created_at"))

# Write the DataFrame to Parquet with partitioning
df.write.mode("append").partitionBy("year", "month", "day", "hour").parquet("/twitter-landing-data/tweett_data.parquet")

from pyspark.sql.functions import when

# Create a new column 'immigration' based on tweet_text
df = df.withColumn('immigration', when(df['tweet_text'].like('%illegal%'), 'illegal')
                   .when(df['tweet_text'].like('%legal%'), 'legal')
                   .otherwise('unknown'))

spark.sql("CREATE DATABASE IF NOT EXISTS my_database")

df.write.mode('overwrite').saveAsTable('my_database.stagetable')

hive_table = spark.sql("SELECT * FROM my_database.stagetable")


