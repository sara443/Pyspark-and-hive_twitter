# Import your dependecies
import pyspark # run after findspark.init() if you need it
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
spark = SparkSession.builder \
        .appName("myApp") \
        .enableHiveSupport() \
        .getOrCreate()
spark.conf.set("hive.metastore.uris", "thrift://localhost:5432")
spark.conf.set("spark.sql.sources.default", "parquet")  
df1 = spark.sql("select tweet_id,tweet_text from my_database.tweet_dim")
df2 = spark.sql("select * from my_database.tweet_properties")
#real_table = df1.join(df2, df1.tweet_id == df2.tweet_id, "inner")

real_table = df1.join(df2, 'tweet_id', 'inner')
# Filter rows where the immigration column has the value "illegal"
illegal_immigration_fact = real_table.filter(real_table.immigration == "illegal")
# Group legal tweets by hour
legal_tweets_by_hour_fact = real_table.where(real_table.immigration == "legal") \
    .groupBy("created_at") \
    .agg(count("*").alias("count_legal_tweets"))
spark.sql("CREATE DATABASE IF NOT EXISTS twitter_processed_data")
# Save fact tables with suffix "-processed"
illegal_immigration_fact.write.mode('overwrite').saveAsTable('twitter_processed_data.illegal_immigration_fact_processed')
legal_tweets_by_hour_fact.write.mode('overwrite').saveAsTable('twitter_processed_data.legal_tweets_by_hour_fact_processed')
# Load fact tables with suffix "-processed"
fact_table1 = spark.sql("SELECT * FROM twitter_processed_data.illegal_immigration_fact_processed")
fact_table2 = spark.sql("SELECT * FROM twitter_processed_data.legal_tweets_by_hour_fact_processed")
