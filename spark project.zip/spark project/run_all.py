import subprocess
import os
# Run script 1 in a new terminal window

subprocess.Popen(('python3', 'twitter_listener.py'))

# Run script 2
subprocess.run(('/opt/spark-3.1.2-bin-hadoop3.2/bin/spark-submit', 'Twitter_stream.py'))

# Run script 3
subprocess.run(('hive', '-f', 'hivescript.hql'))

# Run script 4
subprocess.run(('/opt/spark-3.1.2-bin-hadoop3.2/bin/spark-submit', 'SparkSQL.py'))


